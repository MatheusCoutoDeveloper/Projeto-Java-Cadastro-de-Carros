CREATE DATABASE `projetointer2`;
#Criação das Tabelas

CREATE TABLE `veiculos` (
  `placa` varchar(7) NOT NULL,
  `marca` varchar(10) NOT NULL,
  `modelo` varchar(15) NOT NULL,
  `ano` int(4) NOT NULL,
  `preco` float NOT NULL,
  `estado` varchar(2) NOT NULL,
  `loja` varchar(5) NOT NULL,
  PRIMARY KEY (`placa`));

CREATE TABLE `usuario` (
  `login` varchar(20) NOT NULL,
  `senha` varchar(8) NOT NULL,
  `nome_usuario` varchar(20) NOT NULL,
  UNIQUE KEY `login_UNIQUE` (`login`));

CREATE TABLE `marcamodelo` (
  `marca` varchar(15) NOT NULL,
  `modelo` varchar(15) NOT NULL,
  UNIQUE KEY `modelo_UNIQUE` (`modelo`));

CREATE TABLE `loja` (
  `indentificador` VARCHAR(20) NOT NULL,
  `nome_loja` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`indentificador`));

CREATE TABLE `estados` (
  `sigla` varchar(2) NOT NULL,
  `nome_estado` varchar(20) NOT NULL,
  UNIQUE KEY `sigla_UNIQUE` (`sigla`));


#Insert's

Select * from veiculos;

INSERT INTO `projetointer2`.`veiculos` (`placa`, `marca`, `modelo`, `ano`, `preco`, `estado`, `loja`)
	VALUES ('DNQ2418', 'Chevrolet', 'Corsa', '2005', '15000', 'SP', 'lj-cc');
    
INSERT INTO `projetointer2`.`veiculos` (`placa`, `marca`, `modelo`, `ano`, `preco`, `estado`, `loja`)
	VALUES ('POD1A54', 'VV', 'Gol', '2010', '25000', 'SP', 'lj-cc');
 
INSERT INTO `projetointer2`.`veiculos` (`placa`, `marca`, `modelo`, `ano`, `preco`, `estado`, `loja`) 
	VALUES ('SAF1C57', 'Porsche', 'Cayman', 2018, 80000, 'SP', 'lj-pc');
    
INSERT INTO `projetointer2`.`veiculos` (`placa`, `marca`, `modelo`, `ano`, `preco`, `estado`, `loja`)
	VALUES ('PDD2289', 'VV', 'Gol', '2010', '25000', 'SP', 'lj-tj');
    
INSERT INTO `projetointer2`.`veiculos` (`placa`, `marca`, `modelo`, `ano`, `preco`, `estado`, `loja`)
	VALUES ('FKJ8H69', 'VV', 'Golf', '2012', '35000', 'RJ', 'lj-yu');
    
INSERT INTO `projetointer2`.`veiculos` (`placa`, `marca`, `modelo`, `ano`, `preco`, `estado`, `loja`)
	VALUES ('VCD9E32', 'Ford', 'Fiesta', '2013', '37000', 'MG', 'lj-po');
    
INSERT INTO `veiculos` VALUES ('PPP0A00','Ford','Mustang','2020','300000','AC','lj-ac');
INSERT INTO veiculos VALUES ('OOO0E00','Chevrolet','Monza','1997','10000','BA','lj-ba');

#Tabela Usuario

select * from usuario;

INSERT INTO usuario VALUES ('aninhajt','33333','Ana');
INSERT INTO usuario VALUES ('jaspion22','22222','João');
INSERT INTO usuario VALUES ('jujuba24','544543','Julia');
INSERT INTO usuario VALUES ('math123','558224','Matheus Couto');
INSERT INTO usuario VALUES ('tonx99','111111','Tony Tonx');


#Tabela Estados
select * from estados;
INSERT INTO estados VALUES ('MG','Minas Gerais');
INSERT INTO estados VALUES ('RJ','Rio de Janeiro');
INSERT INTO estados VALUES ('SP','São Paulo');
INSERT INTO estados VALUES ('BA','Bahia');
INSERT INTO estados VALUES ('AC','Acre');


#Tabela marcamodelo
select * from marcamodelo;
INSERT INTO marcamodelo VALUES ('Chevrolet','Celta');
INSERT INTO marcamodelo VALUES ('Chevrolet','Vectra');
INSERT INTO marcamodelo VALUES ('Ford','Fiesta');
INSERT INTO marcamodelo VALUES ('Ford','Fusion');
INSERT INTO marcamodelo VALUES ('VW','Golf');
INSERT INTO marcamodelo VALUES ('VW','Jetta');
INSERT INTO marcamodelo VALUES ('Ford','Mustang');
INSERT INTO marcamodelo VALUES ('Porsche','Cayman');

#Tabela Loja
select * from loja;
DELETE FROM loja WHERE indentificador = 'lj-po,';

INSERT INTO loja VALUES ('lt-tatuape','GrandVel Tatuapé');
INSERT INTO loja VALUES ('lj-vc','Carrão Veículos');
INSERT INTO loja VALUES ('lj-cc','Car Cards');
INSERT INTO loja VALUES ('lj-pc','Pro Car');
INSERT INTO loja VALUES ('lj-ac','Acre Motors');
INSERT INTO loja VALUES ('lj-ba','BahiaCar');
INSERT INTO loja VALUES ('lj-tj','Motors Tijuca');
INSERT INTO loja VALUES ('lj-yu','Yunakata Carros');
INSERT INTO loja VALUES ('lj-po','Projeto O');


SELECT placa, marca, modelo,ano, preco, loja , sigla , nome_estado FROM veiculos, estados where estado = sigla;

SELECT marca, modelo, ano, placa, nome_loja FROM veiculos, loja where loja = indentificador;

SELECT COUNT(DISTINCT marca , modelo) FROM veiculos;

Select ano , preco from veiculos;

SELECT COUNT(DISTINCT marca), COUNT(DISTINCT modelo)  FROM veiculos;

SELECT @PrecoMAX := MAX(preco) FROM veiculos;
SELECT ano AS Ano, @PrecoMAX AS "Preço Maior" FROM veiculos WHERE preco = @PrecoMAX;

SELECT @PrecoMIN := MIN(preco) FROM veiculos;
SELECT ano AS Ano, @PrecoMIN AS "Preço Menor" FROM veiculos WHERE preco = @PrecoMIN;



